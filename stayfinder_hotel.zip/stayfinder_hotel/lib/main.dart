import 'package:flutter/material.dart';
import 'pages/landing_page.dart';
import 'pages/hotel_list_page.dart';
import 'pages/search_page.dart';

void main() {
  runApp(const StayFinderApp());
}

class StayFinderApp extends StatelessWidget {
  const StayFinderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'StayFinder API',

      home: const LandingPage(),

      routes: {
        '/list': (context) => const HotelListPage(),
        '/search': (context) => const SearchPage(),
      },
    );
  }
}
