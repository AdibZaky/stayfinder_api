class Hotel {
  final int id;
  final String name;
  final String location;
  final int price;
  final double rating;
  final String image;
  final List<String> gallery;
  final List<String> facilities;
  final String address;
  final String phone;
  final String mapUrl;
  final String description;

  Hotel({
    required this.id,
    required this.name,
    required this.location,
    required this.price,
    required this.rating,
    required this.image,
    required this.gallery,
    required this.facilities,
    required this.address,
    required this.phone,
    required this.mapUrl,
    required this.description,
  });

  factory Hotel.fromJson(Map<String, dynamic> json) {
    return Hotel(
      id: json["id"],
      name: json["name"],
      location: json["location"],
      price: json["price"],
      rating: (json["rating"] as num).toDouble(),
      image: json["image"],
      gallery: List<String>.from(json["gallery"]),
      facilities: List<String>.from(json["facilities"]),
      address: json["address"],
      phone: json["phone"],
      mapUrl: json["map_url"],
      description: json["description"],
    );
  }
}
