import 'package:flutter/material.dart';
import '../models/hotel_model.dart';
import '../services/hotel_service.dart';
import 'hotel_detail_page.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  List<Hotel> hotels = [];
  List<Hotel> filteredHotels = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadHotels();
  }

  void loadHotels() async {
    hotels = await HotelService.fetchHotels();
    setState(() {
      filteredHotels = hotels;
      loading = false;
    });
  }

  void searchHotel(String query) {
    final results = hotels.where((hotel) {
      final name = hotel.name.toLowerCase();
      final location = hotel.location.toLowerCase();
      final input = query.toLowerCase();

      return name.contains(input) || location.contains(input);
    }).toList();

    setState(() {
      filteredHotels = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Cari Hotel"),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Cari berdasarkan nama atau lokasi...",
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: searchHotel,
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredHotels.length,
              itemBuilder: (context, index) {
                final hotel = filteredHotels[index];
                return ListTile(
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      hotel.image,
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                    ),
                  ),
                  title: Text(hotel.name),
                  subtitle: Text("${hotel.location} • ⭐ ${hotel.rating}"),
                  trailing: Text("Rp ${hotel.price}"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (c) => HotelDetailPage(hotel: hotel),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
