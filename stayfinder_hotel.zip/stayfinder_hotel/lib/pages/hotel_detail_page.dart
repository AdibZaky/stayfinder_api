import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/hotel_model.dart';

class HotelDetailPage extends StatelessWidget {
  final Hotel hotel;

  const HotelDetailPage({super.key, required this.hotel});

  // Buka Google Maps
  Future<void> openMap() async {
    final Uri mapUri = Uri.parse(hotel.mapUrl);
    if (!await launchUrl(mapUri, mode: LaunchMode.externalApplication)) {
      throw Exception("Gagal membuka map");
    }
  }

  // Hubungi via WhatsApp
  Future<void> openWhatsApp() async {
    final Uri waUri = Uri.parse("https://wa.me/${hotel.phone.replaceAll('+', '')}");
    if (!await launchUrl(waUri, mode: LaunchMode.externalApplication)) {
      throw Exception("Gagal membuka WhatsApp");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        elevation: 0,
        title: Text(hotel.name),
        actions: [
          IconButton(
            icon: Icon(Icons.favorite_border, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // --- GALLERY SLIDER ---
            SizedBox(
              height: 260,
              child: PageView.builder(
                itemCount: hotel.gallery.length,
                itemBuilder: (context, index) {
                  return Image.network(
                    hotel.gallery[index],
                    fit: BoxFit.cover,
                  );
                },
              ),
            ),

            // --- HOTEL TITLE ---
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                hotel.name,
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
            ),

            // --- LOCATION + RATING ---
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(Icons.location_on, color: Colors.red),
                  SizedBox(width: 5),
                  Text(
                    hotel.location,
                    style: TextStyle(fontSize: 16),
                  ),
                  Spacer(),
                  Icon(Icons.star, color: Colors.amber),
                  Text(
                    " ${hotel.rating}",
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),

            SizedBox(height: 20),

            // --- PRICE CARD ---
            Container(
              margin: EdgeInsets.symmetric(horizontal: 16),
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue[50],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Text(
                    "Rp ${hotel.price}",
                    style:
                    TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(width: 5),
                  Text("/ malam"),
                ],
              ),
            ),

            SizedBox(height: 20),

            // ---- DESCRIPTION ----
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                "Deskripsi",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                hotel.description,
                style: TextStyle(fontSize: 16, height: 1.5),
                textAlign: TextAlign.justify,
              ),
            ),

            SizedBox(height: 10),

            // ---- FACILITIES ----
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                "Fasilitas",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 12,
                runSpacing: 12,
                children: hotel.facilities
                    .map(
                      (facility) => Chip(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    backgroundColor: Colors.blue[100],
                    label: Text(
                      facility,
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                )
                    .toList(),
              ),
            ),

            SizedBox(height: 10),

            // ---- LOCATION CARD ----
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                "Lokasi",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),

            Container(
              margin: EdgeInsets.all(16),
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(2, 2),
                  )
                ],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(Icons.map, color: Colors.blue),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      hotel.address,
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  TextButton(
                    onPressed: openMap,
                    child: Text("Lihat Peta"),
                  ),
                ],
              ),
            ),

            SizedBox(height: 30),
          ],
        ),
      ),

      // --- BOOKING BUTTON ---
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black12, blurRadius: 8),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.green[700],
                ),
                icon: Icon(Icons.phone),
                label: Text(
                  "Hubungi",
                  style: TextStyle(fontSize: 18),
                ),
                onPressed: openWhatsApp,
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.blue[900],
                ),
                icon: Icon(Icons.shopping_cart),
                label: Text(
                  "Pesan Sekarang",
                  style: TextStyle(fontSize: 18),
                ),
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Fitur booking sedang dikembangkan!"),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
