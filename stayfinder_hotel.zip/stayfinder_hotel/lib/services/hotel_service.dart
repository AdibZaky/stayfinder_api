import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/hotel_model.dart';

class HotelService {
  // Ganti URL ini dengan RAW JSON GitHub kamu
  static const String dataUrl =
      "https://raw.githubusercontent.com/AdibZaky/stayfinder_api/refs/heads/main/hotels.json";

  static Future<List<Hotel>> fetchHotels() async {
    final response = await http.get(Uri.parse(dataUrl));

    if (response.statusCode == 200) {
      List<dynamic> jsonList = json.decode(response.body);
      return jsonList.map((json) => Hotel.fromJson(json)).toList();
    } else {
      throw Exception("Gagal memuat data hotel");
    }
  }
}
