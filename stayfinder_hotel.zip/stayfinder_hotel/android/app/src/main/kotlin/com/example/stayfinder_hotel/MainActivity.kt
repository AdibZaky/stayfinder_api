package com.example.stayfinder_hotel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
